from __future__ import annotations
import io
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

SOURCE_TYPES = ["CSV", "Excel", "Oracle", "Snowflake", "PostgreSQL", "SQL Server"]

def read_uploaded(uploaded, source_type: str, sheet_name=None) -> pd.DataFrame:
    if source_type == "CSV":
        return pd.read_csv(uploaded)
    if source_type == "Excel":
        return pd.read_excel(uploaded, sheet_name=sheet_name or 0)
    raise ValueError(f"Unsupported file type: {source_type}")

def excel_sheets(uploaded):
    data = uploaded.getvalue()
    return pd.ExcelFile(io.BytesIO(data)).sheet_names

def make_engine(source_type: str, cfg: dict):
    if source_type == "Oracle":
        import oracledb  # noqa: F401
        url = URL.create(
            "oracle+oracledb",
            username=cfg["username"], password=cfg["password"],
            host=cfg["host"], port=int(cfg.get("port", 1521)),
            query={"service_name": cfg["service_name"]},
        )
    elif source_type == "Snowflake":
        from snowflake.sqlalchemy import URL as SFURL
        url = SFURL(
            account=cfg["account"], user=cfg["username"], password=cfg["password"],
            warehouse=cfg["warehouse"], database=cfg["database"], schema=cfg["schema"],
        )
    elif source_type == "PostgreSQL":
        url = URL.create(
            "postgresql+psycopg2",
            username=cfg["username"], password=cfg["password"],
            host=cfg["host"], port=int(cfg.get("port", 5432)), database=cfg["database"],
        )
    elif source_type == "SQL Server":
        url = URL.create(
            "mssql+pyodbc",
            username=cfg["username"], password=cfg["password"],
            host=cfg["host"], port=int(cfg.get("port", 1433)), database=cfg["database"],
            query={"driver": cfg.get("driver", "ODBC Driver 18 for SQL Server"),
                   "TrustServerCertificate": "yes"},
        )
    else:
        raise ValueError(f"Unsupported database type: {source_type}")
    return create_engine(url, pool_pre_ping=True)

def read_database(source_type: str, cfg: dict, query: str) -> pd.DataFrame:
    engine = make_engine(source_type, cfg)
    try:
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn)
    finally:
        engine.dispose()
