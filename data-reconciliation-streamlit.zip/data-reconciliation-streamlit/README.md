# Data Reconciliation Streamlit

Compare any supported Source A against Source B:

- CSV
- Excel
- Oracle
- Snowflake
- PostgreSQL
- SQL Server

## Features

- File-to-file, DB-to-file, file-to-DB, and DB-to-DB
- Table or custom SQL query
- Automatic same-name column mapping
- Manual Source A -> Source B column mapping
- Single or composite business keys
- Trim strings, ignore case, normalize nulls
- Numeric tolerance
- Duplicate-key detection
- Matched rows, mismatched rows, Source-A-only, Source-B-only
- Field-level mismatch report
- Download comparison results as Excel workbook

## Run

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
# source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Database notes

Oracle: host, port, service name, username, password.
Snowflake: account, username, password, warehouse, database, schema.
PostgreSQL: host, port, database, username, password.
SQL Server: host, port, database, username, password and an installed ODBC Driver 18 for SQL Server.

For large production tables, use a SQL query/filter to reduce the comparison set. This starter performs the final comparison in pandas memory.
