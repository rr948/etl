import streamlit as st
import pandas as pd
from connectors.sources import SOURCE_TYPES, read_uploaded, read_database, excel_sheets
from engine.compare import compare_frames, to_excel_bytes

st.set_page_config(page_title="Data Reconciliation", page_icon="🔎", layout="wide")
st.title("🔎 Data Reconciliation")
st.caption("Compare files and databases using business keys, mappings and normalization rules.")

FILE_TYPES = {"CSV", "Excel"}

def source_panel(prefix, label):
    st.subheader(label)
    typ = st.selectbox("Source type", SOURCE_TYPES, key=f"{prefix}_type")
    if typ in FILE_TYPES:
        ext = ["csv"] if typ == "CSV" else ["xlsx", "xlsm", "xls"]
        up = st.file_uploader(f"Upload {typ}", type=ext, key=f"{prefix}_file")
        sheet = None
        if up and typ == "Excel":
            try:
                sheets = excel_sheets(up)
                sheet = st.selectbox("Sheet", sheets, key=f"{prefix}_sheet")
            except Exception as e:
                st.error(f"Could not read workbook: {e}")
        return {"type": typ, "upload": up, "sheet": sheet}

    cfg = {}
    if typ == "Snowflake":
        cfg["account"] = st.text_input("Account", key=f"{prefix}_account")
        cfg["username"] = st.text_input("Username", key=f"{prefix}_user")
        cfg["password"] = st.text_input("Password", type="password", key=f"{prefix}_pwd")
        cfg["warehouse"] = st.text_input("Warehouse", key=f"{prefix}_wh")
        cfg["database"] = st.text_input("Database", key=f"{prefix}_db")
        cfg["schema"] = st.text_input("Schema", key=f"{prefix}_schema")
    else:
        cfg["host"] = st.text_input("Host", key=f"{prefix}_host")
        default_port = {"Oracle": 1521, "PostgreSQL": 5432, "SQL Server": 1433}[typ]
        cfg["port"] = st.number_input("Port", 1, 65535, default_port, key=f"{prefix}_port")
        if typ == "Oracle":
            cfg["service_name"] = st.text_input("Service name", key=f"{prefix}_service")
        else:
            cfg["database"] = st.text_input("Database", key=f"{prefix}_db")
        cfg["username"] = st.text_input("Username", key=f"{prefix}_user")
        cfg["password"] = st.text_input("Password", type="password", key=f"{prefix}_pwd")
        if typ == "SQL Server":
            cfg["driver"] = st.text_input("ODBC driver", "ODBC Driver 18 for SQL Server",
                                          key=f"{prefix}_driver")
    query = st.text_area("SQL query", placeholder="SELECT * FROM schema.table WHERE ...",
                         height=110, key=f"{prefix}_query")
    return {"type": typ, "cfg": cfg, "query": query}

def load_source(src):
    if src["type"] in FILE_TYPES:
        if not src["upload"]:
            raise ValueError(f"Upload the {src['type']} file.")
        return read_uploaded(src["upload"], src["type"], src.get("sheet"))
    if not src.get("query", "").strip():
        raise ValueError("Enter a SQL query.")
    return read_database(src["type"], src["cfg"], src["query"])

c1, c2 = st.columns(2)
with c1:
    src_a = source_panel("a", "Source A")
with c2:
    src_b = source_panel("b", "Source B")

if st.button("Load / Reload Sources", type="primary", use_container_width=True):
    try:
        with st.spinner("Loading sources..."):
            st.session_state["df_a"] = load_source(src_a)
            st.session_state["df_b"] = load_source(src_b)
            st.session_state.pop("result", None)
        st.success("Both sources loaded.")
    except Exception as e:
        st.error(f"Load failed: {e}")

if "df_a" in st.session_state and "df_b" in st.session_state:
    a, b = st.session_state["df_a"], st.session_state["df_b"]
    st.divider()
    x1, x2 = st.columns(2)
    with x1:
        st.metric("Source A rows", f"{len(a):,}")
        st.dataframe(a.head(20), use_container_width=True)
    with x2:
        st.metric("Source B rows", f"{len(b):,}")
        st.dataframe(b.head(20), use_container_width=True)

    st.subheader("Comparison Configuration")
    common = [c for c in a.columns if c in b.columns]
    mapping = {}
    selected_a = st.multiselect(
        "Source A columns to compare",
        list(a.columns),
        default=common if common else list(a.columns)[:min(10, len(a.columns))]
    )
    for ca in selected_a:
        default_idx = list(b.columns).index(ca) if ca in b.columns else 0
        cb = st.selectbox(f"{ca}  →  Source B", list(b.columns),
                          index=default_idx, key=f"map_{ca}")
        mapping[ca] = cb

    key_a = st.multiselect("Business key(s)", selected_a,
                           default=selected_a[:1] if selected_a else [])
    o1, o2, o3, o4 = st.columns(4)
    trim = o1.checkbox("Trim strings", True)
    ignore_case = o2.checkbox("Ignore case", True)
    normalize_null = o3.checkbox("Normalize NULL", True)
    tolerance = o4.number_input("Numeric tolerance", min_value=0.0, value=0.0,
                                step=0.01, format="%.6f")

    if st.button("Compare Data", type="primary", use_container_width=True):
        try:
            if not key_a:
                raise ValueError("Select at least one business key.")
            with st.spinner("Comparing..."):
                st.session_state["result"] = compare_frames(
                    a, b, mapping, key_a, trim=trim, ignore_case=ignore_case,
                    normalize_null=normalize_null, numeric_tolerance=tolerance
                )
        except Exception as e:
            st.error(f"Comparison failed: {e}")

if "result" in st.session_state:
    r = st.session_state["result"]
    s = r["summary"]
    st.divider()
    st.subheader("Comparison Results")
    cols = st.columns(6)
    metrics = [
        ("Matched", s["matched_keys"]), ("Mismatched", s["mismatched_keys"]),
        ("Only A", s["only_a"]), ("Only B", s["only_b"]),
        ("Duplicates A", s["duplicate_rows_a"]), ("Duplicates B", s["duplicate_rows_b"])
    ]
    for col, (name, value) in zip(cols, metrics):
        col.metric(name, f"{value:,}")

    tabs = st.tabs(["Field Mismatches", "Mismatched Keys", "Only A", "Only B",
                    "Duplicates A", "Duplicates B", "Matched"])
    keys = ["details", "mismatched", "only_a", "only_b",
            "duplicates_a", "duplicates_b", "matched"]
    for tab, key in zip(tabs, keys):
        with tab:
            st.dataframe(r[key], use_container_width=True, height=400)

    st.download_button(
        "Download Excel Report",
        data=to_excel_bytes(r),
        file_name="comparison_results.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )
