from __future__ import annotations
import io
import numpy as np
import pandas as pd

NULL_TOKEN = "<NULL>"

def _norm_series(s: pd.Series, trim=True, ignore_case=True, normalize_null=True):
    out = s.copy()
    if pd.api.types.is_datetime64_any_dtype(out):
        out = pd.to_datetime(out, errors="coerce").dt.strftime("%Y-%m-%d %H:%M:%S.%f")
    elif pd.api.types.is_object_dtype(out) or pd.api.types.is_string_dtype(out):
        out = out.astype("string")
        if trim:
            out = out.str.strip()
        if ignore_case:
            out = out.str.casefold()
    if normalize_null:
        out = out.astype("object").where(pd.notna(out), NULL_TOKEN)
    return out

def _equal(a: pd.Series, b: pd.Series, tolerance: float):
    an = pd.to_numeric(a, errors="coerce")
    bn = pd.to_numeric(b, errors="coerce")
    both_numeric = an.notna() & bn.notna()
    result = pd.Series(False, index=a.index)
    if both_numeric.any():
        result.loc[both_numeric] = (an[both_numeric] - bn[both_numeric]).abs() <= tolerance
    other = ~both_numeric
    if other.any():
        result.loc[other] = a[other].eq(b[other])
    return result

def compare_frames(a, b, mapping, key_a, *, trim=True, ignore_case=True,
                   normalize_null=True, numeric_tolerance=0.0):
    if not mapping:
        raise ValueError("At least one column mapping is required.")
    key_b = [mapping[k] for k in key_a]
    if len(set(key_b)) != len(key_b):
        raise ValueError("Mapped key columns in Source B must be unique.")

    aa = a[list(mapping.keys())].copy()
    bb = b[list(mapping.values())].copy()
    bb.columns = list(mapping.keys())  # canonicalize to A names

    for c in aa.columns:
        aa[c] = _norm_series(aa[c], trim, ignore_case, normalize_null)
        bb[c] = _norm_series(bb[c], trim, ignore_case, normalize_null)

    dup_a = aa[aa.duplicated(key_a, keep=False)].copy()
    dup_b = bb[bb.duplicated(key_a, keep=False)].copy()

    # Compare unique keys deterministically. Duplicates are reported separately.
    au = aa.drop_duplicates(key_a, keep="first")
    bu = bb.drop_duplicates(key_a, keep="first")
    merged = au.merge(bu, on=key_a, how="outer", suffixes=("_A", "_B"), indicator=True)

    only_a = merged[merged["_merge"] == "left_only"].copy()
    only_b = merged[merged["_merge"] == "right_only"].copy()
    both = merged[merged["_merge"] == "both"].copy()

    compare_cols = [c for c in aa.columns if c not in key_a]
    row_equal = pd.Series(True, index=both.index)
    detail_rows = []

    for c in compare_cols:
        ca, cb = f"{c}_A", f"{c}_B"
        eq = _equal(both[ca], both[cb], numeric_tolerance)
        row_equal &= eq
        bad = both.loc[~eq, key_a + [ca, cb]]
        for _, r in bad.iterrows():
            item = {k: r[k] for k in key_a}
            item.update({"column": c, "source_a": r[ca], "source_b": r[cb]})
            detail_rows.append(item)

    matched = both.loc[row_equal].copy()
    mismatched = both.loc[~row_equal].copy()
    details = pd.DataFrame(detail_rows)

    summary = {
        "source_a_rows": len(a),
        "source_b_rows": len(b),
        "matched_keys": len(matched),
        "mismatched_keys": len(mismatched),
        "only_a": len(only_a),
        "only_b": len(only_b),
        "duplicate_rows_a": len(dup_a),
        "duplicate_rows_b": len(dup_b),
    }
    return {
        "summary": summary, "matched": matched, "mismatched": mismatched,
        "only_a": only_a, "only_b": only_b, "duplicates_a": dup_a,
        "duplicates_b": dup_b, "details": details,
    }

def to_excel_bytes(result):
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        pd.DataFrame([result["summary"]]).to_excel(writer, "Summary", index=False)
        for key, sheet in [
            ("details", "Field Mismatches"), ("mismatched", "Mismatched Keys"),
            ("only_a", "Only Source A"), ("only_b", "Only Source B"),
            ("duplicates_a", "Duplicates A"), ("duplicates_b", "Duplicates B"),
            ("matched", "Matched"),
        ]:
            result[key].to_excel(writer, sheet[:31], index=False)
    return bio.getvalue()
